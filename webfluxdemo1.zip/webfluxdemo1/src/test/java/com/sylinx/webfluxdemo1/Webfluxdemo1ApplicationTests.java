package com.sylinx.webfluxdemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Webfluxdemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
