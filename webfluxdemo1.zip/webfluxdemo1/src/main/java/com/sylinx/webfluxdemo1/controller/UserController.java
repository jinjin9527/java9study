package com.sylinx.webfluxdemo1.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sylinx.webfluxdemo1.domain.User;
import com.sylinx.webfluxdemo1.repository.UserRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/user")
public class UserController {

	private final UserRepository repository;
	
	public UserController(UserRepository repository) {
		this.repository = repository;
	}
	
	@GetMapping(value = "/")
	public Flux<User> getAll(){
		return repository.findAll();
	}
	
	@GetMapping(value = "/stream/all", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<User> streamGetAll(){
		return repository.findAll();
	}
	
	@PostMapping("/")
	public Mono<User> createUser(@RequestBody User user) {
		// spring data jpa里面 新增和修改都是save id是修改 id为空是新增
		user.setId(null);
		return this.repository.save(user);
	}
	
	/**
	 * 用户存在返回200  不存在返回404
	 * @param id
	 * @return
	 */
	@DeleteMapping("/{id}")
	public Mono<ResponseEntity<Void>> deleteUser(@PathVariable("id") String id) {
		// delete by id 没有返回值  不能判断数据是否存在
		//this.repository.deleteById(id);
		
		// 当你要操作数据，并返回一个Mono 这个时候用flatmap
		// 如果不操作数据，只能转换数据 使用map
		
		return this.repository.findById(id)
		.flatMap(user -> this.repository.delete(user)
			.then(Mono.just(new ResponseEntity<Void>(HttpStatus.OK))))
			.defaultIfEmpty(new ResponseEntity<Void>(HttpStatus.NOT_FOUND));
		
	}
	
	/**
	 * 修改数据
	 * 存在的时候返回200和修改后的数据，不存在的时候
	 * 
	 * @param id
	 * @param user
	 * @return
	 */
	@PutMapping("/{id}")
	public Mono<ResponseEntity<User>> updateUser(@PathVariable("id") String id, @RequestBody User user) {
		
		// flatmap 操作数据
		// map 转换数据
		return this.repository.findById(id)
				.flatMap(u -> {
					u.setAge(user.getAge());
					u.setName(user.getName());
					return this.repository.save(u);
				}).map(u -> new ResponseEntity<User>(u, HttpStatus.OK))
				.defaultIfEmpty(new ResponseEntity<User>(HttpStatus.NOT_FOUND));
	}
	
	/**
	 * 修改数据
	 * 存在的时候返回200和修改后的数据，不存在的时候
	 * 
	 * @param id
	 * @param user
	 * @return
	 */
	@GetMapping("/{id}")
	public Mono<ResponseEntity<User>> findUser(@PathVariable("id") String id, @RequestBody User user) {
		
		// flatmap 操作数据
		// map 转换数据
		return this.repository.findById(id).map(u -> new ResponseEntity<User>(u, HttpStatus.OK))
				.defaultIfEmpty(new ResponseEntity<User>(HttpStatus.NOT_FOUND));
	}
	
}
