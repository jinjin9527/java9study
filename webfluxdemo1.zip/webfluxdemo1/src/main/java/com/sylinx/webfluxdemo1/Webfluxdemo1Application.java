package com.sylinx.webfluxdemo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableReactiveMongoRepositories;

@SpringBootApplication
@EnableReactiveMongoRepositories
public class Webfluxdemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Webfluxdemo1Application.class, args);
	}

}
